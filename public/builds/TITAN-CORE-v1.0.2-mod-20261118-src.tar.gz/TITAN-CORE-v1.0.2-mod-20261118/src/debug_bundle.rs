//! Forensics collector for TITAN-CORE Mod v2.2:
//! - Bounded 256-slot error/errno ring buffer
//! - Real FreeBSD getrusage + KERN_PROC_VMMAP region counter & AMPR map check
//! - Active nullfs/unionfs mount graph & collision detector (getmntinfo)
//! - Atomic /data/titan-core/debug/ bundle export & panic-crash writer

use serde_json::{json, Value};
use std::collections::VecDeque;
use std::fs;
use std::path::Path;
use std::sync::{Mutex, OnceLock};

pub const DEBUG_DIR: &str = "/data/titan-core/debug";
const MAX_ERRORS: usize = 256;

#[derive(Clone)]
pub struct RecordedError {
    pub ts_ms: u64,
    pub title_id: String,
    pub errno: i32,
    pub message: String,
}

fn ring() -> &'static Mutex<VecDeque<RecordedError>> {
    static RING: OnceLock<Mutex<VecDeque<RecordedError>>> = OnceLock::new();
    RING.get_or_init(|| Mutex::new(VecDeque::with_capacity(MAX_ERRORS)))
}

fn now_ms() -> u64 {
    let mut ts: libc::timespec = unsafe { std::mem::zeroed() };
    unsafe { libc::clock_gettime(libc::CLOCK_MONOTONIC, &mut ts) };
    (ts.tv_sec as u64)
        .saturating_mul(1000)
        .saturating_add((ts.tv_nsec as u64) / 1_000_000)
}

pub fn record_error(title_id: &str, errno: i32, message: impl Into<String>) {
    let mut q = ring().lock().unwrap_or_else(|e| e.into_inner());
    if q.len() >= MAX_ERRORS {
        q.pop_front();
    }
    q.push_back(RecordedError {
        ts_ms: now_ms(),
        title_id: title_id.to_owned(),
        errno,
        message: message.into(),
    });
}

pub fn error_dump_json() -> Value {
    let q = ring().lock().unwrap_or_else(|e| e.into_inner());
    let items: Vec<Value> = q
        .iter()
        .map(|e| json!({"ts_ms": e.ts_ms, "title_id": e.title_id, "errno": e.errno, "message": e.message}))
        .collect();
    let crash_bundle = fs::read_to_string(Path::new(DEBUG_DIR).join("last-crash-bundle.json")).ok();
    json!({
        "count": items.len(),
        "capacity": MAX_ERRORS,
        "errors": items,
        "last_crash_bundle": crash_bundle,
    })
}

#[cfg(target_os = "freebsd")]
fn inspect_vmmap(pid: libc::pid_t) -> (usize, bool) {
    // FreeBSD KERN_PROC_VMMAP = 32
    let mut mib = [libc::CTL_KERN, libc::KERN_PROC, 32, pid];
    let mut vm_bytes: libc::size_t = 0;
    let vm_ok = unsafe {
        libc::sysctl(mib.as_mut_ptr(), 4, std::ptr::null_mut(), &mut vm_bytes, std::ptr::null(), 0) == 0
    };
    let mut ampr_mapped = false;
    let mut vm_regions = 0usize;
    if vm_ok && vm_bytes > 0 && vm_bytes <= (4 << 20) {
        let mut buf = vec![0u8; vm_bytes];
        if unsafe { libc::sysctl(mib.as_mut_ptr(), 4, buf.as_mut_ptr().cast(), &mut vm_bytes, std::ptr::null(), 0) == 0 } {
            let mut off = 0usize;
            while off + 4 <= vm_bytes {
                let sz = i32::from_ne_bytes(buf[off..off + 4].try_into().unwrap_or([0; 4])) as usize;
                if sz < 8 || off + sz > vm_bytes {
                    break;
                }
                vm_regions += 1;
                if buf[off..off + sz]
                    .windows(10)
                    .any(|w| w.eq_ignore_ascii_case(b"libSceAmpr"))
                {
                    ampr_mapped = true;
                }
                off += sz;
            }
        }
    }
    (vm_regions, ampr_mapped)
}

#[cfg(not(target_os = "freebsd"))]
fn inspect_vmmap(_pid: libc::pid_t) -> (usize, bool) {
    (0, false)
}

pub fn memory_snapshot_json() -> Value {
    let mut ru: libc::rusage = unsafe { std::mem::zeroed() };
    unsafe { libc::getrusage(libc::RUSAGE_SELF, &mut ru) };
    let pid = unsafe { libc::getpid() };
    let (vm_regions, ampr_mapped) = inspect_vmmap(pid);
    let free_data_gib = crate::storage::drives()
        .into_iter()
        .find(|d| d.mount == "/data")
        .map_or(0.0, |d| (d.free as f64) / ((1u64 << 30) as f64));

    json!({
        "pid": pid,
        "rss_kib": ru.ru_maxrss,
        "rss_mib": (ru.ru_maxrss as f64 / 1024.0).round() as u64,
        "page_faults_minor": ru.ru_minflt,
        "page_faults_major": ru.ru_majflt,
        "ctx_voluntary": ru.ru_nvcsw,
        "ctx_involuntary": ru.ru_nivcsw,
        "vm_regions_count": vm_regions,
        "ampr_mapped": ampr_mapped,
        "ampr_pool_mib": 256,
        "flexible_budget_mib": 448,
        "free_data_gib": free_data_gib,
    })
}

#[cfg(target_os = "freebsd")]
pub fn mounts_snapshot_json() -> Value {
    use std::collections::BTreeMap;
    use std::ffi::CStr;

    let mut p: *mut libc::statfs = std::ptr::null_mut();
    let n = unsafe { libc::getmntinfo(&mut p, libc::MNT_NOWAIT) };
    let mut list = Vec::new();
    let mut common_lib_counts: BTreeMap<String, usize> = BTreeMap::new();
    if n > 0 && !p.is_null() {
        let slice = unsafe { std::slice::from_raw_parts(p, n as usize) };
        for m in slice {
            let fstype = unsafe { CStr::from_ptr(m.f_fstypename.as_ptr()) }.to_string_lossy().into_owned();
            let from = unsafe { CStr::from_ptr(m.f_mntfromname.as_ptr()) }.to_string_lossy().into_owned();
            let on = unsafe { CStr::from_ptr(m.f_mntonname.as_ptr()) }.to_string_lossy().into_owned();
            if fstype == "unionfs" && on.contains("common/lib") {
                *common_lib_counts.entry(on.clone()).or_insert(0) += 1;
            }
            list.push(json!({
                "fstype": fstype,
                "from": from,
                "on": on,
                "rdonly": (m.f_flags & (libc::MNT_RDONLY as u64)) != 0,
            }));
        }
    }
    let collisions: Vec<String> = common_lib_counts
        .into_iter()
        .filter(|(_, c)| *c > 1)
        .map(|(k, _)| k)
        .collect();
    json!({ "mounts": list, "unionfs_collisions": collisions })
}

#[cfg(not(target_os = "freebsd"))]
pub fn mounts_snapshot_json() -> Value {
    json!({ "mounts": [], "unionfs_collisions": [] })
}

pub fn write_bundle(filename: &str, formats: Value) -> Result<Value, String> {
    write_bundle_in(Path::new(DEBUG_DIR), filename, formats)
}

pub fn write_bundle_in(dir: &Path, filename: &str, formats: Value) -> Result<Value, String> {
    fs::create_dir_all(dir).map_err(|e| e.to_string())?;
    let bundle = json!({
        "version": format!("{}-mod-v2.2", env!("CARGO_PKG_VERSION")),
        "amprVersion": "0.4.1-3ced5c0",
        "memory": memory_snapshot_json(),
        "mounts": mounts_snapshot_json(),
        "errors": error_dump_json(),
        "formatsDetected": formats,
    });
    let out_path = dir.join(filename);
    let tmp = dir.join(format!("{filename}.tmp"));
    fs::write(&tmp, serde_json::to_vec_pretty(&bundle).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())?;
    fs::rename(&tmp, &out_path).map_err(|e| e.to_string())?;
    Ok(bundle)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ring_buffer_is_bounded_and_preserves_latest() {
        for i in 0..300 {
            record_error("PPSA00001", i, format!("err-{i}"));
        }
        let dump = error_dump_json();
        let arr = dump["errors"].as_array().unwrap();
        assert_eq!(arr.len(), MAX_ERRORS);
        assert_eq!(arr.last().unwrap()["errno"], 299);
    }

    #[test]
    fn atomic_bundle_writer_persists_valid_json() {
        let dir = std::env::temp_dir().join(format!("titan_dbg_{}", std::process::id()));
        let _ = fs::remove_dir_all(&dir);
        let written = write_bundle_in(&dir, "test-bundle.json", json!({"formats": {}})).unwrap();
        assert_eq!(written["amprVersion"], "0.4.1-3ced5c0");
        assert!(dir.join("test-bundle.json").is_file());
        let _ = fs::remove_dir_all(&dir);
    }
}
