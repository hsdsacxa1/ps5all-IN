//! Unified PS5 13.60 dump format registry and classifier for TITAN-CORE Mod v2.2.
//! Covers unpacked folders (plain/lz4/zstd), debug/sparse/split FPKGs (.pkg),
//! UFS2/compressed PFS images (.ffpkg/.ffpfsc), standalone archives (.zst/.lz4),
//! and raw/exFAT disk images (.exfat/.img).

use serde_json::{json, Value};
use std::collections::BTreeMap;
use std::path::Path;

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum DumpFormat {
    FolderPlain,
    FolderLz4,
    FolderZstd,
    PkgStandardOrSparse,
    PkgSplitPart,
    PfsFfpkg,
    PfsFfpfsc,
    ArchiveZstd,
    ArchiveLz4,
    DiskExfatOrImg,
}

impl DumpFormat {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::FolderPlain => "folder-plain",
            Self::FolderLz4 => "folder-lz4",
            Self::FolderZstd => "folder-zstd",
            Self::PkgStandardOrSparse => "pkg-debug-sparse",
            Self::PkgSplitPart => "pkg-split-part",
            Self::PfsFfpkg => "pfs-ffpkg",
            Self::PfsFfpfsc => "pfs-ffpfsc",
            Self::ArchiveZstd => "archive-zstd",
            Self::ArchiveLz4 => "archive-lz4",
            Self::DiskExfatOrImg => "image-exfat-img",
        }
    }

    pub fn engine_hint(self) -> &'static str {
        match self {
            Self::FolderPlain | Self::FolderLz4 | Self::FolderZstd | Self::PkgStandardOrSparse => "titan-native",
            Self::PkgSplitPart => "merge-split-parts-first",
            Self::PfsFfpkg | Self::PfsFfpfsc | Self::DiskExfatOrImg => "shadowmountplus-1.7b12",
            Self::ArchiveZstd | Self::ArchiveLz4 => "kraken-or-unpack-host",
        }
    }
}

pub fn classify_path(path: &Path) -> Option<DumpFormat> {
    if path.is_dir() {
        if path.join("ampr_zstd.index").is_file() || path.join("apr.zstd.chunks").is_file() {
            return Some(DumpFormat::FolderZstd);
        }
        if path.join("ampr_assets.index").is_file() {
            return Some(DumpFormat::FolderLz4);
        }
        if path.join("eboot.bin").is_file() && path.join("sce_sys/param.json").is_file() {
            return Some(DumpFormat::FolderPlain);
        }
        return None;
    }
    let ext = path.extension()?.to_str()?.to_ascii_lowercase();
    match ext.as_str() {
        "pkg" => {
            let stem = path.file_stem().and_then(|s| s.to_str()).unwrap_or("");
            let is_split = stem
                .rsplit_once('_')
                .is_some_and(|(_, n)| !n.is_empty() && n.bytes().all(|b| b.is_ascii_digit()));
            Some(if is_split {
                DumpFormat::PkgSplitPart
            } else {
                DumpFormat::PkgStandardOrSparse
            })
        }
        "ffpkg" => Some(DumpFormat::PfsFfpkg),
        "ffpfsc" => Some(DumpFormat::PfsFfpfsc),
        "zst" | "zstd" => Some(DumpFormat::ArchiveZstd),
        "lz4" => Some(DumpFormat::ArchiveLz4),
        "exfat" | "img" => Some(DumpFormat::DiskExfatOrImg),
        _ => None,
    }
}

pub fn summarize_inventory(native: &[Value], images: &[Value]) -> Value {
    let mut counts: BTreeMap<&'static str, usize> = BTreeMap::new();
    for g in native.iter().chain(images.iter()) {
        let p = g["path"].as_str().map(Path::new);
        if let Some(fmt) = p.and_then(classify_path) {
            *counts.entry(fmt.as_str()).or_insert(0) += 1;
        }
    }
    json!({
        "formats": counts,
        "ampr_pool_mib": 256,
        "cnt_fallbacks": 16,
        "supported_extensions": [".pkg", ".ffpkg", ".ffpfsc", ".zst", ".zstd", ".lz4", ".exfat", ".img"],
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;

    #[test]
    fn classifies_all_supported_extensions_and_split_pkgs() {
        assert_eq!(classify_path(Path::new("/data/games/PPSA01234.pkg")), Some(DumpFormat::PkgStandardOrSparse));
        assert_eq!(classify_path(Path::new("/mnt/usb0/games/game_0.pkg")), Some(DumpFormat::PkgSplitPart));
        assert_eq!(classify_path(Path::new("/mnt/usb0/homebrew/demo.ffpkg")), Some(DumpFormat::PfsFfpkg));
        assert_eq!(classify_path(Path::new("/mnt/usb0/homebrew/demo.ffpfsc")), Some(DumpFormat::PfsFfpfsc));
        assert_eq!(classify_path(Path::new("/data/homebrew/bundle.zst")), Some(DumpFormat::ArchiveZstd));
        assert_eq!(classify_path(Path::new("/data/homebrew/bundle.lz4")), Some(DumpFormat::ArchiveLz4));
        assert_eq!(classify_path(Path::new("/data/homebrew/disk.exfat")), Some(DumpFormat::DiskExfatOrImg));
        assert_eq!(classify_path(Path::new("/data/homebrew/disk.img")), Some(DumpFormat::DiskExfatOrImg));
        assert_eq!(classify_path(Path::new("/data/homebrew/readme.txt")), None);
    }

    #[test]
    fn classifies_folder_variants() {
        let tmp = std::env::temp_dir().join(format!("titan_fmt_{}", std::process::id()));
        let _ = fs::remove_dir_all(&tmp);
        fs::create_dir_all(tmp.join("sce_sys")).unwrap();
        fs::write(tmp.join("eboot.bin"), b"ELF").unwrap();
        fs::write(tmp.join("sce_sys/param.json"), b"{}").unwrap();
        assert_eq!(classify_path(&tmp), Some(DumpFormat::FolderPlain));
        fs::write(tmp.join("ampr_assets.index"), b"AMPR").unwrap();
        assert_eq!(classify_path(&tmp), Some(DumpFormat::FolderLz4));
        fs::write(tmp.join("ampr_zstd.index"), b"AMPR").unwrap();
        assert_eq!(classify_path(&tmp), Some(DumpFormat::FolderZstd));
        let _ = fs::remove_dir_all(&tmp);
    }
}
